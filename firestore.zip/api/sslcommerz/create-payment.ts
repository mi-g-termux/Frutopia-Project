// api/sslcommerz/create-payment.ts
// SSLCommerz session create — returns GatewayPageURL for redirect.

import type { VercelRequest, VercelResponse } from '@vercel/node';
import { getGatewayCreds, missingCreds } from '../_lib/getGatewayCreds';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { amount, orderId, customer = {}, productName = 'Order' } = req.body || {};
    if (!amount || !orderId) return res.status(400).json({ error: 'amount and orderId required' });

    const creds = await getGatewayCreds('sslcommerz');
    const missing = missingCreds(creds, ['storeId', 'storePass']);
    if (missing.length) {
      return res.status(500).json({ error: `Missing SSLCommerz credentials: ${missing.join(', ')}` });
    }

    const sandbox = String(creds.isSandbox).toLowerCase() !== 'false';
    const base = sandbox
      ? 'https://sandbox.sslcommerz.com'
      : 'https://securepay.sslcommerz.com';

    const origin = getOrigin(req);
    const form = new URLSearchParams({
      store_id: creds.storeId,
      store_passwd: creds.storePass,
      total_amount: String(amount),
      currency: 'BDT',
      tran_id: orderId,
      success_url: `${origin}/api/sslcommerz/ipn?status=success&orderId=${orderId}`,
      fail_url: `${origin}/api/sslcommerz/ipn?status=fail&orderId=${orderId}`,
      cancel_url: `${origin}/api/sslcommerz/ipn?status=cancel&orderId=${orderId}`,
      ipn_url: `${origin}/api/sslcommerz/ipn`,
      cus_name: customer.name || 'Customer',
      cus_email: customer.email || 'noreply@example.com',
      cus_phone: customer.phone || '01700000000',
      cus_add1: customer.address || 'N/A',
      cus_city: customer.city || 'Dhaka',
      cus_country: customer.country || 'Bangladesh',
      shipping_method: 'NO',
      product_name: productName,
      product_category: 'general',
      product_profile: 'general',
    });

    const r = await fetch(`${base}/gwprocess/v4/api.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: form.toString(),
    });
    const j: any = await r.json();
    if (j?.status !== 'SUCCESS' || !j?.GatewayPageURL) {
      return res.status(502).json({ error: 'SSLCommerz session failed', detail: j });
    }
    return res.status(200).json({ redirectUrl: j.GatewayPageURL, sessionkey: j.sessionkey });
  } catch (e: any) {
    console.error('[sslcz/create]', e);
    return res.status(500).json({ error: e?.message });
  }
}

function getOrigin(req: VercelRequest): string {
  const proto = (req.headers['x-forwarded-proto'] as string) || 'https';
  return `${proto}://${req.headers.host}`;
}
